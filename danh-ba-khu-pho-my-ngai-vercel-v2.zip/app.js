(() => {
  const state = { query: '', area: 'all', role: 'all' };
  const $ = (selector) => document.querySelector(selector);
  const grid = $('#directoryGrid');
  const emptyState = $('#emptyState');
  const searchInput = $('#searchInput');
  const areaFilter = $('#areaFilter');
  const roleFilter = $('#roleFilter');
  const resultCount = $('#resultCount');
  const clearSearchBtn = $('#clearSearchBtn');
  const toast = $('#toast');
  let toastTimer;

  function normalizeVietnamese(value = '') {
    return String(value)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normalizePhone(value = '') { return String(value).replace(/\D/g, ''); }

  function escapeHtml(value = '') {
    return String(value).replace(/[&<>'"]/g, (char) => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[char]));
  }

  function showToast(message) {
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add('show');
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2000);
  }

  async function copyText(text, successMessage = '✓ Đã sao chép số điện thoại') {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
      else {
        const area = document.createElement('textarea');
        area.value = text; area.style.position = 'fixed'; area.style.opacity = '0';
        document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
      }
      showToast(successMessage);
    } catch { showToast('Không thể sao chép. Vui lòng thử lại.'); }
  }

  function directionsUrl(item) {
    const destination = item.viTriBanDo || `${item.truSo}, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam`;
    return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}&travelmode=driving`;
  }

  function shareText(item) {
    return `KHU PHỐ ${item.khuPho.toUpperCase()}\nUBND PHƯỜNG MỸ NGÃI\n\nBí thư Chi bộ:\n${item.biThu.hoTen}\nĐiện thoại: ${item.biThu.dienThoai}\n\nTrưởng Khu phố:\n${item.truongKhuPho.hoTen}\n${item.truongKhuPho.chucDanh}\nĐiện thoại: ${item.truongKhuPho.dienThoai}\n\nTrụ sở:\n${item.truSo}\n\nChỉ đường:\n${directionsUrl(item)}`;
  }

  async function shareItem(id) {
    const item = khuPhoData.find((entry) => entry.id === id);
    if (!item) return;
    const text = shareText(item);
    try {
      if (navigator.share) await navigator.share({ title: `Khu phố ${item.khuPho} - Phường Mỹ Ngãi`, text });
      else await copyText(text, '✓ Đã sao chép thông tin để chia sẻ');
    } catch (error) {
      if (error?.name !== 'AbortError') await copyText(text, '✓ Đã sao chép thông tin để chia sẻ');
    }
  }

  function phoneButton(person, ownerLabel) {
    const phone = normalizePhone(person.dienThoai);
    return `
      <div class="phone-line"><span aria-hidden="true">☎</span><a href="tel:${phone}" aria-label="Gọi ${escapeHtml(ownerLabel)} số ${escapeHtml(person.dienThoai)}">${escapeHtml(person.dienThoai)}</a></div>
      <div class="person-actions">
        <a class="mini-btn call" href="tel:${phone}" aria-label="Gọi ngay ${escapeHtml(ownerLabel)}">☎ Gọi ngay</a>
        <button class="mini-btn" type="button" data-copy="${escapeHtml(person.dienThoai)}" aria-label="Sao chép số điện thoại của ${escapeHtml(ownerLabel)}">⧉ Sao chép</button>
      </div>`;
  }

  function renderCard(item) {
    return `
      <article class="directory-card" data-id="${item.id}">
        <div class="card-top">
          <div class="card-no">${String(item.id).padStart(2,'0')}</div>
          <small>Khu phố</small>
          <h3>${escapeHtml(item.khuPho)}</h3>
        </div>
        <section class="person" aria-label="Bí thư Chi bộ ${escapeHtml(item.khuPho)}">
          <span class="role-badge">◆ Bí thư Chi bộ</span>
          <h4>${escapeHtml(item.biThu.hoTen)}</h4>
          <p class="title">${escapeHtml(item.biThu.chucDanh)}</p>
          ${phoneButton(item.biThu, item.biThu.hoTen)}
        </section>
        <section class="person" aria-label="Trưởng Khu phố ${escapeHtml(item.khuPho)}">
          <span class="role-badge leader">● Trưởng Khu phố</span>
          <h4>${escapeHtml(item.truongKhuPho.hoTen)}</h4>
          <p class="title">${escapeHtml(item.truongKhuPho.chucDanh)}</p>
          ${phoneButton(item.truongKhuPho, item.truongKhuPho.hoTen)}
        </section>
        <div class="location">
          <span class="location-icon" aria-hidden="true">⌖</span>
          <div class="location-content">
            <b>TRỤ SỞ</b>
            <p>${escapeHtml(item.truSo)}</p>
            <a class="map-btn" href="${escapeHtml(directionsUrl(item))}" target="_blank" rel="noopener noreferrer" aria-label="Chỉ đường đến trụ sở Khu phố ${escapeHtml(item.khuPho)} bằng Google Maps">📍 Chỉ đường</a>
          </div>
        </div>
        <button class="share-btn" type="button" data-share="${item.id}" aria-label="Chia sẻ thông tin Khu phố ${escapeHtml(item.khuPho)}">↗ Chia sẻ thông tin</button>
      </article>`;
  }

  function matchesRole(item, queryNorm, phoneQuery) {
    if (state.role === 'all') return true;
    const person = state.role === 'secretary' ? item.biThu : item.truongKhuPho;
    if (!state.query) return true;
    const text = normalizeVietnamese(`${person.hoTen} ${person.chucDanh} ${person.dienThoai}`);
    return text.includes(queryNorm) || normalizePhone(person.dienThoai).includes(phoneQuery);
  }

  function filteredData() {
    const q = normalizeVietnamese(state.query);
    const phoneQ = normalizePhone(state.query);
    return khuPhoData.filter((item) => {
      if (state.area !== 'all' && item.khuPho !== state.area) return false;
      if (!matchesRole(item, q, phoneQ)) return false;
      if (!state.query) return true;
      const searchable = normalizeVietnamese(`${item.khuPho} ${item.biThu.hoTen} ${item.biThu.chucDanh} ${item.biThu.dienThoai} ${item.truongKhuPho.hoTen} ${item.truongKhuPho.chucDanh} ${item.truongKhuPho.dienThoai} ${item.truSo} ${item.viTriBanDo || ''}`);
      const phones = `${normalizePhone(item.biThu.dienThoai)} ${normalizePhone(item.truongKhuPho.dienThoai)}`;
      return searchable.includes(q) || (phoneQ && phones.includes(phoneQ));
    });
  }

  function render() {
    const data = filteredData();
    grid.innerHTML = data.map(renderCard).join('');
    grid.hidden = data.length === 0;
    emptyState.hidden = data.length !== 0;
    resultCount.textContent = `${data.length} khu phố`;
    clearSearchBtn.hidden = !state.query;
  }

  function resetAll() {
    state.query = ''; state.area = 'all'; state.role = 'all';
    searchInput.value = ''; areaFilter.value = 'all'; roleFilter.value = 'all';
    render();
    searchInput.focus();
  }

  function setupFilters() {
    areaFilter.insertAdjacentHTML('beforeend', khuPhoData.map((item) => `<option value="${escapeHtml(item.khuPho)}">${escapeHtml(item.khuPho)}</option>`).join(''));
    searchInput.addEventListener('input', (event) => { state.query = event.target.value; render(); });
    areaFilter.addEventListener('change', (event) => { state.area = event.target.value; render(); });
    roleFilter.addEventListener('change', (event) => { state.role = event.target.value; render(); });
    $('#resetFilters').addEventListener('click', resetAll);
    $('#emptyReset').addEventListener('click', resetAll);
    clearSearchBtn.addEventListener('click', () => { state.query = ''; searchInput.value = ''; render(); searchInput.focus(); });
  }

  function setupGridActions() {
    grid.addEventListener('click', (event) => {
      const copy = event.target.closest('[data-copy]');
      const share = event.target.closest('[data-share]');
      if (copy) copyText(copy.dataset.copy);
      if (share) shareItem(Number(share.dataset.share));
    });
  }

  function setupTheme() {
    const root = document.documentElement;
    const saved = localStorage.getItem('myngai-theme');
    const preferred = window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    let current = saved || preferred;
    const apply = () => {
      root.dataset.theme = current;
      $('#themeIcon').textContent = current === 'dark' ? '☀' : '☾';
      $('#themeToggle').setAttribute('aria-label', current === 'dark' ? 'Chuyển sang chế độ sáng' : 'Chuyển sang chế độ tối');
    };
    apply();
    $('#themeToggle').addEventListener('click', () => { current = current === 'dark' ? 'light' : 'dark'; localStorage.setItem('myngai-theme', current); apply(); });
  }

  function setupCounters() {
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    document.querySelectorAll('.counter').forEach((counter) => {
      const target = Number(counter.dataset.target || 0);
      if (reduceMotion) { counter.textContent = target; return; }
      const started = performance.now(); const duration = 650;
      const step = (now) => { const p = Math.min(1, (now - started) / duration); counter.textContent = Math.round(target * (1 - Math.pow(1-p,3))); if (p < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }

  function setupBackToTop() {
    const button = $('#backToTop');
    const update = () => button.classList.toggle('show', window.scrollY > 500);
    window.addEventListener('scroll', update, { passive: true }); update();
    button.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  function setupPWA() {
    if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
  }

  function init() {
    setupTheme(); setupFilters(); setupGridActions(); setupCounters(); setupBackToTop(); setupPWA();
    $('#year').textContent = new Date().getFullYear();
    render();
  }

  init();
})();
