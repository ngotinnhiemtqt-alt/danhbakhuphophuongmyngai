const khuPhoData = [
  {
    id: 1,
    khuPho: "Tân An",
    biThu: { hoTen: "Dương Thị Thu Ba", chucDanh: "Bí thư Chi bộ", dienThoai: "0939 669 509" },
    truongKhuPho: { hoTen: "Nguyễn Thị Vân Nhung", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0903 304 060" },
    truSo: "Quốc lộ 30, tổ 7, Khu phố Tân An (trụ sở Khóm 1 cũ)",
    viTriBanDo: "Quốc lộ 30, Tổ 7, Khu phố Tân An, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 2,
    khuPho: "Trần Quốc Toản",
    biThu: { hoTen: "Nguyễn Thị Kim Loan", chucDanh: "Bí thư Chi bộ", dienThoai: "0919 121 274" },
    truongKhuPho: { hoTen: "Lê Hoàng Vinh", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0939 703 435" },
    truSo: "Số 71, đường Tân Định, tổ 21, Khu phố Trần Quốc Toản (trụ sở Khóm 3 cũ)",
    viTriBanDo: "Số 71, đường Tân Định, Tổ 21, Khu phố Trần Quốc Toản, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 3,
    khuPho: "Tân Định",
    biThu: { hoTen: "Nguyễn Thành Được", chucDanh: "Bí thư Chi bộ", dienThoai: "0969 890 113" },
    truongKhuPho: { hoTen: "Nguyễn Văn Sang", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0988 165 716" },
    truSo: "Đường Lưu Kim Phong, Tổ 32, Khu phố Tân Định (trụ sở Khóm 4 cũ)",
    viTriBanDo: "Đường Lưu Kim Phong, Tổ 32, Khu phố Tân Định, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 4,
    khuPho: "Mỹ Phước",
    biThu: { hoTen: "Nguyễn Thị Kim Thúy", chucDanh: "Bí thư Chi bộ", dienThoai: "0939 606 164" },
    truongKhuPho: { hoTen: "Võ Thanh Hòa", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0939 537 767" },
    truSo: "Đường Nguyễn Chí Thanh, Khu phố Mỹ Phước (trụ sở Khóm 7 cũ)",
    viTriBanDo: "Đường Nguyễn Chí Thanh, Khu phố Mỹ Phước, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 5,
    khuPho: "Tân Nhất",
    biThu: { hoTen: "Nguyễn Văn Thanh", chucDanh: "Bí thư Chi bộ", dienThoai: "0939 200 919" },
    truongKhuPho: { hoTen: "Lê Thị Bạch Ngọc", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0396 949 060" },
    truSo: "Tổ 15, đường ấp Chiến Lược, Khu phố Tân Nhất (trụ sở Khóm 9 cũ)",
    viTriBanDo: "Tổ 15, đường Ấp Chiến Lược, Khu phố Tân Nhất, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 6,
    khuPho: "Mỹ Tân",
    biThu: { hoTen: "Nguyễn Thái Hồ", chucDanh: "Bí thư Chi bộ", dienThoai: "0907 760 916" },
    truongKhuPho: { hoTen: "Nguyễn Văn Trường", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0988 522 833" },
    truSo: "Khu dân cư Bà Học, đường số 4, tổ 12, Khu phố Mỹ Tân (trụ sở Khóm 10 cũ)",
    viTriBanDo: "Khu dân cư Bà Học, đường số 4, Tổ 12, Khu phố Mỹ Tân, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 7,
    khuPho: "Mỹ Phong",
    biThu: { hoTen: "Huỳnh Văn Diệu", chucDanh: "Bí thư Chi bộ", dienThoai: "0913 831 064" },
    truongKhuPho: { hoTen: "Hồ Bảo Triệu Duy", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0907 466 586" },
    truSo: "Số 39 đường số 2, tổ 3, Khu phố Mỹ Phong (trụ sở Khóm 11 cũ)",
    viTriBanDo: "Số 39 đường số 2, Tổ 3, Khu phố Mỹ Phong, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 8,
    khuPho: "Mỹ Lợi",
    biThu: { hoTen: "Thái Nguyên", chucDanh: "Bí thư Chi bộ", dienThoai: "0362 998 113" },
    truongKhuPho: { hoTen: "Lê Văn Phú Quý", chucDanh: "Trưởng Khu phố", dienThoai: "0768 506 711" },
    truSo: "Đường Bà Học bờ trên, Tổ 7, Khu phố Mỹ Lợi (trụ sở Khóm 12 cũ)",
    viTriBanDo: "Đường Bà Học bờ trên, Tổ 7, Khu phố Mỹ Lợi, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 9,
    khuPho: "Tân Tiến",
    biThu: { hoTen: "Nguyễn Văn Liếng", chucDanh: "Bí thư Chi bộ", dienThoai: "0762 925 762" },
    truongKhuPho: { hoTen: "Nguyễn Văn Mơ", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0899 308 970" },
    truSo: "Tổ 12, đường Ngã Đồng, Khu phố Tân Tiến (trụ sở Khóm 13 cũ, gần bến đò 5 Vui)",
    viTriBanDo: "Tổ 12, đường Ngã Đồng, Khu phố Tân Tiến, gần bến đò 5 Vui, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 10,
    khuPho: "Tân Nghĩa",
    biThu: { hoTen: "Phan Văn Nghĩa", chucDanh: "Bí thư Chi bộ", dienThoai: "0944 346 484" },
    truongKhuPho: { hoTen: "Huỳnh Văn Thắng", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0337 272 846" },
    truSo: "Tổ 1, Khu phố Tân Nghĩa (Trung tâm Văn hóa học tập cộng đồng xã Tân Nghĩa cũ)",
    viTriBanDo: "Trung tâm Văn hóa học tập cộng đồng xã Tân Nghĩa cũ, Tổ 1, Khu phố Tân Nghĩa, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 11,
    khuPho: "Tân Hòa",
    biThu: { hoTen: "Trương Thanh Vĩnh", chucDanh: "Bí thư Chi bộ", dienThoai: "0327 610 657" },
    truongKhuPho: { hoTen: "Mai Văn Tấn Đạt", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0385 789 354" },
    truSo: "Bờ Nam kênh Ông Kho, Tổ 03, Khu phố Tân Hòa (trụ sở Khóm 15 cũ)",
    viTriBanDo: "Bờ Nam kênh Ông Kho, Tổ 03, Khu phố Tân Hòa, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  },
  {
    id: 12,
    khuPho: "Tân Thuận",
    biThu: { hoTen: "Lê Văn Lên", chucDanh: "Bí thư Chi bộ", dienThoai: "0948 293 348" },
    truongKhuPho: { hoTen: "Lê Thị Như Ngọc", chucDanh: "Phó Bí thư Chi bộ, Trưởng Khu phố", dienThoai: "0382 859 881" },
    truSo: "Đường Bà Đông kênh Tư Tịnh, Tổ 13, Khu phố Tân Thuận (trụ sở Khóm 16 cũ)",
    viTriBanDo: "Đường Bà Đông kênh Tư Tịnh, Tổ 13, Khu phố Tân Thuận, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam"
  }
];
