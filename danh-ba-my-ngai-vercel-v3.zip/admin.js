(() => {
  'use strict';

  const STORAGE = { khuPho:'myngai-khupho-data-v3', staff:'myngai-staff-data-v3', meta:'myngai-meta-data-v3' };
  const PIN_KEY = 'myngai-admin-pin-hash-v1';
  const SESSION_KEY = 'myngai-admin-auth-v1';
  const clone = v => JSON.parse(JSON.stringify(v));
  const originals = { khuPho:clone(khuPhoData), staff:clone(danhBaCanBoData), meta:clone(appMeta) };
  const loadLocal = (key,fallback) => { try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):clone(fallback);}catch{return clone(fallback);} };
  let data = { khuPho:loadLocal(STORAGE.khuPho,originals.khuPho), staff:loadLocal(STORAGE.staff,originals.staff), meta:loadLocal(STORAGE.meta,originals.meta) };
  let currentAreaId = data.khuPho[0]?.id || 1;
  let currentStaffId = data.staff[0]?.id || '';
  let toastTimer;
  const $ = s => document.querySelector(s);

  function showToast(message){clearTimeout(toastTimer);const t=$('#toast');t.textContent=message;t.classList.add('show');toastTimer=setTimeout(()=>t.classList.remove('show'),2200);}
  function saveAll(){localStorage.setItem(STORAGE.khuPho,JSON.stringify(data.khuPho));localStorage.setItem(STORAGE.staff,JSON.stringify(data.staff));localStorage.setItem(STORAGE.meta,JSON.stringify(data.meta));}
  function normalize(value=''){return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();}
  function validGps(g){return g&&Number.isFinite(Number(g.lat))&&Number.isFinite(Number(g.lng));}
  function mapValue(gps,query){return validGps(gps)?`${Number(gps.lat).toFixed(7)},${Number(gps.lng).toFixed(7)}`:query;}
  function mapUrl(gps,query){return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapValue(gps,query||''))}`;}

  async function sha256(text){const bytes=new TextEncoder().encode(text);const hash=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('');}
  function configureAuthPanel(){
    const hasPin=!!localStorage.getItem(PIN_KEY);$('#pinConfirmWrap').hidden=hasPin;$('#authTitle').textContent=hasPin?'Đăng nhập quản trị':'Thiết lập mã PIN quản trị';$('#authSubmit').textContent=hasPin?'Đăng nhập':'Tạo mã PIN';$('#pinLabel').textContent=hasPin?'Mã PIN':'Tạo mã PIN (ít nhất 4 ký tự)';$('#pinInput').autocomplete=hasPin?'current-password':'new-password';
    if(sessionStorage.getItem(SESSION_KEY)==='1') unlock();
  }
  async function handleAuth(e){e.preventDefault();const pin=$('#pinInput').value; if(pin.length<4){showToast('Mã PIN cần ít nhất 4 ký tự.');return;} const existing=localStorage.getItem(PIN_KEY);
    if(!existing){if(pin!==$('#pinConfirm').value){showToast('Hai lần nhập PIN chưa khớp.');return;}localStorage.setItem(PIN_KEY,await sha256(pin));sessionStorage.setItem(SESSION_KEY,'1');showToast('✓ Đã tạo PIN quản trị');unlock();return;}
    if(await sha256(pin)===existing){sessionStorage.setItem(SESSION_KEY,'1');unlock();}else showToast('Mã PIN không đúng.');
  }
  function unlock(){ $('#authPanel').hidden=true;$('#adminWorkspace').hidden=false;renderAllEditors(); }

  function setupTheme(){const root=document.documentElement,saved=localStorage.getItem('myngai-theme'),preferred=window.matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light';let current=saved||preferred;const apply=()=>{root.dataset.theme=current;$('#themeIcon').textContent=current==='dark'?'☀':'☾';};apply();$('#themeToggle').addEventListener('click',()=>{current=current==='dark'?'light':'dark';localStorage.setItem('myngai-theme',current);apply();});}

  function renderAreaSelect(){const sel=$('#adminAreaSelect');sel.innerHTML=data.khuPho.map(x=>`<option value="${x.id}">${String(x.id).padStart(2,'0')} - ${x.khuPho}</option>`).join('');sel.value=String(currentAreaId);}
  function areaById(id=currentAreaId){return data.khuPho.find(x=>x.id===Number(id));}
  function fillAreaForm(){const x=areaById();if(!x)return;$('#aKhuPho').value=x.khuPho||'';$('#aTruSo').value=x.truSo||'';$('#aMapQuery').value=x.viTriBanDo||'';$('#aBiThuName').value=x.biThu?.hoTen||'';$('#aBiThuRole').value=x.biThu?.chucDanh||'';$('#aBiThuPhone').value=x.biThu?.dienThoai||'';$('#aLeaderName').value=x.truongKhuPho?.hoTen||'';$('#aLeaderRole').value=x.truongKhuPho?.chucDanh||'';$('#aLeaderPhone').value=x.truongKhuPho?.dienThoai||'';$('#aLat').value=validGps(x.gps)?x.gps.lat:'';$('#aLng').value=validGps(x.gps)?x.gps.lng:'';$('#gpsAccuracy').textContent=validGps(x.gps)?`Đã có GPS: ${Number(x.gps.lat).toFixed(7)}, ${Number(x.gps.lng).toFixed(7)}`:'Chưa thiết lập GPS chính xác.';updateAreaPreview();$('#areaSaveState').textContent='Đã tải dữ liệu';}
  function readGps(latSel,lngSel){const lat=String($(latSel).value).trim(),lng=String($(lngSel).value).trim();if(!lat&&!lng)return null;const a=Number(lat.replace(',','.')),b=Number(lng.replace(',','.'));if(!Number.isFinite(a)||!Number.isFinite(b)||a<-90||a>90||b<-180||b>180)throw new Error('Tọa độ GPS không hợp lệ.');return{lat:a,lng:b};}
  function saveArea(e){e.preventDefault();const x=areaById();if(!x)return;let gps;try{gps=readGps('#aLat','#aLng');}catch(err){showToast(err.message);return;}x.khuPho=$('#aKhuPho').value.trim();x.truSo=$('#aTruSo').value.trim();x.viTriBanDo=$('#aMapQuery').value.trim();x.biThu={hoTen:$('#aBiThuName').value.trim(),chucDanh:$('#aBiThuRole').value.trim(),dienThoai:$('#aBiThuPhone').value.trim()};x.truongKhuPho={hoTen:$('#aLeaderName').value.trim(),chucDanh:$('#aLeaderRole').value.trim(),dienThoai:$('#aLeaderPhone').value.trim()};x.gps=gps;saveAll();renderAreaSelect();$('#areaSaveState').textContent='✓ Đã lưu trên trình duyệt';showToast('✓ Đã lưu dữ liệu khu phố');}
  function updateAreaPreview(){const x=areaById();if(!x)return;let gps=null;try{gps=readGps('#aLat','#aLng');}catch{}$('#previewAreaMap').href=mapUrl(gps,$('#aMapQuery').value.trim()||x.truSo);}
  function captureGps(latSel,lngSel,noteSel){if(!navigator.geolocation){showToast('Trình duyệt không hỗ trợ định vị.');return;}showToast('Đang lấy GPS…');navigator.geolocation.getCurrentPosition(pos=>{$(latSel).value=pos.coords.latitude.toFixed(7);$(lngSel).value=pos.coords.longitude.toFixed(7);if(noteSel)$(noteSel).textContent=`Độ chính xác thiết bị báo khoảng ${Math.round(pos.coords.accuracy)} m. Hãy đứng tại đúng trụ sở để ghim điểm.`;updateAreaPreview();showToast('✓ Đã lấy tọa độ hiện tại');},err=>showToast(err.code===1?'Bạn chưa cho phép truy cập vị trí.':'Không lấy được GPS.'),{enableHighAccuracy:true,timeout:15000,maximumAge:0});}
  function resetCurrentArea(){const orig=originals.khuPho.find(x=>x.id===currentAreaId);if(!orig)return;if(!confirm('Khôi phục khu phố này về dữ liệu nguồn?'))return;const idx=data.khuPho.findIndex(x=>x.id===currentAreaId);data.khuPho[idx]=clone(orig);saveAll();fillAreaForm();renderAreaSelect();showToast('Đã khôi phục khu phố');}

  function sectionOptions(){const map=new Map();danhMucCanBo.forEach(x=>map.set(x.code,x.label));data.staff.forEach(x=>map.set(x.sectionCode,x.section));return [...map.entries()];}
  function populateStaffSectionCodes(){const sel=$('#sSectionCode');sel.innerHTML=sectionOptions().map(([code,label])=>`<option value="${code}">${code} - ${label}</option>`).join('');}
  function staffById(id=currentStaffId){return data.staff.find(x=>x.id===id);}
  function renderStaffSelect(){const q=normalize($('#staffAdminSearch').value);const items=data.staff.filter(x=>!q||normalize(`${x.hoTen} ${x.dienThoai} ${x.chucDanh}`).includes(q));const sel=$('#adminStaffSelect');if(!items.length){sel.innerHTML='<option value="">Không tìm thấy bản ghi</option>';currentStaffId='';fillStaffForm();return;}sel.innerHTML=items.map(x=>`<option value="${x.id}">${x.hoTen}${x.dienThoai?` - ${x.dienThoai}`:''}</option>`).join('');if(!items.some(x=>x.id===currentStaffId))currentStaffId=items[0].id;sel.value=currentStaffId;fillStaffForm();}
  function fillStaffForm(){const x=staffById();populateStaffSectionCodes();if(!x){['#sName','#sPhone','#sRole','#sSection','#sGroup','#sEmail'].forEach(s=>$(s).value='');$('#deleteStaffBtn').disabled=true;return;}$('#sName').value=x.hoTen||'';$('#sPhone').value=x.dienThoai||'';$('#sRole').value=x.chucDanh||'';$('#sSectionCode').value=x.sectionCode||'A';$('#sSection').value=x.section||'';$('#sGroup').value=x.group||'';$('#sEmail').value=x.email||'';$('#deleteStaffBtn').disabled=false;}
  function saveStaff(e){e.preventDefault();const x=staffById();if(!x)return;x.hoTen=$('#sName').value.trim();x.dienThoai=$('#sPhone').value.trim();x.chucDanh=$('#sRole').value.trim();x.sectionCode=$('#sSectionCode').value;x.section=$('#sSection').value.trim();x.group=$('#sGroup').value.trim();x.email=$('#sEmail').value.trim();saveAll();renderStaffSelect();showToast('✓ Đã lưu cán bộ');}
  function addStaff(){const nums=data.staff.map(x=>Number(String(x.id).replace(/\D/g,''))).filter(Number.isFinite);const id=`CB${String(Math.max(0,...nums)+1).padStart(3,'0')}`;const sec=sectionOptions()[0]||['A','A – ĐẢNG UỶ'];data.staff.push({id,sectionCode:sec[0],section:sec[1],group:'',stt:'',hoTen:'Cán bộ mới',chucDanh:'',dienThoai:'',email:''});currentStaffId=id;saveAll();$('#staffAdminSearch').value='';renderStaffSelect();showToast('Đã tạo bản ghi mới');}
  function deleteStaff(){const x=staffById();if(!x||!confirm(`Xóa bản ghi “${x.hoTen}”?`))return;data.staff=data.staff.filter(y=>y.id!==currentStaffId);currentStaffId=data.staff[0]?.id||'';saveAll();renderStaffSelect();showToast('Đã xóa bản ghi');}
  function resetCurrentStaff(){const orig=originals.staff.find(x=>x.id===currentStaffId);if(!orig){showToast('Bản ghi mới không có dữ liệu nguồn để khôi phục.');return;}const idx=data.staff.findIndex(x=>x.id===currentStaffId);data.staff[idx]=clone(orig);saveAll();fillStaffForm();renderStaffSelect();showToast('Đã khôi phục bản gốc');}

  function fillOfficeForm(){const x=data.meta;$('#oName').value=x.tenDonVi||'';$('#oAddress').value=x.diaChi||'';$('#oPhone').value=x.dienThoai||'';$('#oEmail').value=x.email||'';$('#oMapQuery').value=x.mapQuery||'';$('#oLat').value=validGps(x.gps)?x.gps.lat:'';$('#oLng').value=validGps(x.gps)?x.gps.lng:'';}
  function saveOffice(e){e.preventDefault();let gps;try{gps=readGps('#oLat','#oLng');}catch(err){showToast(err.message);return;}data.meta={...data.meta,tenDonVi:$('#oName').value.trim(),diaChi:$('#oAddress').value.trim(),dienThoai:$('#oPhone').value.trim(),email:$('#oEmail').value.trim(),mapQuery:$('#oMapQuery').value.trim(),gps};saveAll();showToast('✓ Đã lưu thông tin UBND');}

  function createExportObject(){return{version:3,exportedAt:new Date().toISOString(),appMeta:data.meta,khuPhoData:data.khuPho,danhBaCanBoData:data.staff};}
  function downloadText(filename,text,type='text/plain;charset=utf-8'){const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function exportJson(){downloadText('my-ngai-danh-ba-backup.json',JSON.stringify(createExportObject(),null,2),'application/json;charset=utf-8');showToast('✓ Đã xuất bản sao lưu JSON');}
  function exportDataJs(){const sectionMap=new Map();data.staff.forEach(x=>sectionMap.set(x.sectionCode,x.section));const dm=[...sectionMap.entries()].map(([code,label])=>({code,label}));const text=`// Dữ liệu được xuất từ trang quản trị Danh bạ Phường Mỹ Ngãi.\n// Xuất lúc: ${new Date().toLocaleString('vi-VN')}\n\nconst appMeta = ${JSON.stringify(data.meta,null,2)};\n\nconst khuPhoData = ${JSON.stringify(data.khuPho,null,2)};\n\nconst danhBaCanBoData = ${JSON.stringify(data.staff,null,2)};\n\nconst danhMucCanBo = ${JSON.stringify(dm,null,2)};\n`;downloadText('data.js',text,'text/javascript;charset=utf-8');showToast('✓ Đã xuất data.js');}
  async function importJson(file){try{const parsed=JSON.parse(await file.text());if(!Array.isArray(parsed.khuPhoData)||!Array.isArray(parsed.danhBaCanBoData)||!parsed.appMeta)throw new Error('Cấu trúc file không đúng.');data={khuPho:parsed.khuPhoData,staff:parsed.danhBaCanBoData,meta:parsed.appMeta};currentAreaId=data.khuPho[0]?.id||1;currentStaffId=data.staff[0]?.id||'';saveAll();renderAllEditors();showToast('✓ Đã nhập bản sao lưu');}catch(err){showToast(`Không thể nhập file: ${err.message}`);}}
  function resetAllData(){if(!confirm('Khôi phục toàn bộ dữ liệu về bản có sẵn trong source? Tất cả chỉnh sửa cục bộ sẽ mất.'))return;data={khuPho:clone(originals.khuPho),staff:clone(originals.staff),meta:clone(originals.meta)};currentAreaId=data.khuPho[0]?.id||1;currentStaffId=data.staff[0]?.id||'';saveAll();renderAllEditors();showToast('Đã khôi phục toàn bộ dữ liệu nguồn');}

  function switchAdminTab(tab){document.querySelectorAll('.admin-tab').forEach(b=>b.classList.toggle('active',b.dataset.adminTab===tab));['Areas','Staff','Office','Backup'].forEach(name=>$('#panel'+name).hidden=name.toLowerCase()!==tab);}
  function renderAllEditors(){renderAreaSelect();fillAreaForm();populateStaffSectionCodes();renderStaffSelect();fillOfficeForm();}

  function setupEvents(){
    $('#authForm').addEventListener('submit',handleAuth);$('#logoutBtn').addEventListener('click',()=>{sessionStorage.removeItem(SESSION_KEY);location.reload();});
    document.querySelectorAll('.admin-tab').forEach(b=>b.addEventListener('click',()=>switchAdminTab(b.dataset.adminTab)));
    $('#adminAreaSelect').addEventListener('change',e=>{currentAreaId=Number(e.target.value);fillAreaForm();});$('#areaForm').addEventListener('submit',saveArea);['#aLat','#aLng','#aMapQuery'].forEach(s=>$(s).addEventListener('input',updateAreaPreview));
    $('#captureAreaGps').addEventListener('click',()=>captureGps('#aLat','#aLng','#gpsAccuracy'));$('#clearAreaGps').addEventListener('click',()=>{$('#aLat').value='';$('#aLng').value='';$('#gpsAccuracy').textContent='GPS đã được xóa khỏi biểu mẫu. Bấm Lưu thay đổi để xác nhận.';updateAreaPreview();});$('#resetArea').addEventListener('click',resetCurrentArea);
    $('#staffAdminSearch').addEventListener('input',renderStaffSelect);$('#adminStaffSelect').addEventListener('change',e=>{currentStaffId=e.target.value;fillStaffForm();});$('#staffForm').addEventListener('submit',saveStaff);$('#addStaffBtn').addEventListener('click',addStaff);$('#deleteStaffBtn').addEventListener('click',deleteStaff);$('#resetStaffBtn').addEventListener('click',resetCurrentStaff);
    $('#sSectionCode').addEventListener('change',e=>{const entry=sectionOptions().find(([code])=>code===e.target.value);if(entry)$('#sSection').value=entry[1];});
    $('#officeForm').addEventListener('submit',saveOffice);$('#captureOfficeGps').addEventListener('click',()=>captureGps('#oLat','#oLng'));$('#clearOfficeGps').addEventListener('click',()=>{$('#oLat').value='';$('#oLng').value='';});
    $('#exportJson').addEventListener('click',exportJson);$('#exportDataJs').addEventListener('click',exportDataJs);$('#exportDataJs2').addEventListener('click',exportDataJs);$('#importJson').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)importJson(f);e.target.value='';});$('#resetAllData').addEventListener('click',resetAllData);
  }

  setupTheme();setupEvents();configureAuthPanel();
})();
