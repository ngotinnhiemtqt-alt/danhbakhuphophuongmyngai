(() => {
  'use strict';

  const STORAGE = {
    khuPho: 'myngai-khupho-data-v3',
    staff: 'myngai-staff-data-v3',
    meta: 'myngai-meta-data-v3'
  };

  const clone = (value) => JSON.parse(JSON.stringify(value));
  const loadLocal = (key, fallback) => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : clone(fallback);
    } catch { return clone(fallback); }
  };

  const data = {
    khuPho: loadLocal(STORAGE.khuPho, khuPhoData),
    staff: loadLocal(STORAGE.staff, danhBaCanBoData),
    meta: loadLocal(STORAGE.meta, appMeta)
  };

  const state = {
    mode: 'khuPho', query: '', area: 'all', role: 'all', section: 'all', group: 'all',
    userLocation: null, currentMapLink: ''
  };

  const $ = (selector) => document.querySelector(selector);
  const grid = $('#directoryGrid');
  const staffDirectory = $('#staffDirectory');
  const emptyState = $('#emptyState');
  const searchInput = $('#searchInput');
  const areaFilter = $('#areaFilter');
  const roleFilter = $('#roleFilter');
  const sectionFilter = $('#sectionFilter');
  const groupFilter = $('#groupFilter');
  const resultCount = $('#resultCount');
  const clearSearchBtn = $('#clearSearchBtn');
  const toast = $('#toast');
  const mapDialog = $('#mapDialog');
  let toastTimer;

  function normalizeVietnamese(value = '') {
    return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function normalizePhone(value = '') { return String(value).replace(/\D/g, ''); }
  function escapeHtml(value = '') { return String(value).replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function validGps(gps) { return gps && Number.isFinite(Number(gps.lat)) && Number.isFinite(Number(gps.lng)); }
  function showToast(message) { clearTimeout(toastTimer); toast.textContent = message; toast.classList.add('show'); toastTimer = setTimeout(() => toast.classList.remove('show'), 2200); }

  async function copyText(text, successMessage = '✓ Đã sao chép') {
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
      else {
        const area = document.createElement('textarea'); area.value = text; area.style.position = 'fixed'; area.style.opacity = '0';
        document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
      }
      showToast(successMessage);
    } catch { showToast('Không thể sao chép. Vui lòng thử lại.'); }
  }

  function mapDestination(item) {
    if (validGps(item.gps)) return `${Number(item.gps.lat).toFixed(7)},${Number(item.gps.lng).toFixed(7)}`;
    return item.viTriBanDo || item.mapQuery || item.truSo || data.meta.mapQuery || data.meta.diaChi;
  }
  function directionsUrl(item) {
    const destination = mapDestination(item);
    const origin = state.userLocation ? `&origin=${encodeURIComponent(`${state.userLocation.lat},${state.userLocation.lng}`)}` : '';
    return `https://www.google.com/maps/dir/?api=1${origin}&destination=${encodeURIComponent(destination)}&travelmode=driving`;
  }
  function mapSearchUrl(item) { return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapDestination(item))}`; }
  function mapEmbedUrl(item) { return `https://www.google.com/maps?q=${encodeURIComponent(mapDestination(item))}&z=17&output=embed`; }
  function qrUrl(link) { return `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent(link)}`; }

  function haversineKm(a, b) {
    const R = 6371; const rad = (d) => d * Math.PI / 180;
    const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
    const x = Math.sin(dLat/2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng/2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function distanceText(item) {
    if (!state.userLocation) return '';
    if (!validGps(item.gps)) return 'Khoảng cách: cần GPS chính xác';
    const km = haversineKm(state.userLocation, {lat:Number(item.gps.lat), lng:Number(item.gps.lng)});
    return km < 1 ? `Cách khoảng ${Math.round(km * 1000)} m` : `Cách khoảng ${km.toFixed(km < 10 ? 1 : 0)} km`;
  }

  function phoneActions(person, ownerLabel) {
    const phone = normalizePhone(person.dienThoai);
    if (!phone) return '<span class="no-phone">Chưa có số điện thoại trong danh bạ nguồn</span>';
    return `
      <div class="phone-line"><span aria-hidden="true">☎</span><a href="tel:${phone}" aria-label="Gọi ${escapeHtml(ownerLabel)} số ${escapeHtml(person.dienThoai)}">${escapeHtml(person.dienThoai)}</a></div>
      <div class="person-actions">
        <a class="mini-btn call" href="tel:${phone}" aria-label="Gọi ngay ${escapeHtml(ownerLabel)}">☎ Gọi ngay</a>
        <button class="mini-btn" type="button" data-copy="${escapeHtml(person.dienThoai)}" aria-label="Sao chép số điện thoại của ${escapeHtml(ownerLabel)}">⧉ Sao chép</button>
      </div>`;
  }

  function shareText(item) {
    return `KHU PHỐ ${item.khuPho.toUpperCase()}\nUBND PHƯỜNG MỸ NGÃI\n\nBí thư Chi bộ:\n${item.biThu.hoTen}\nĐiện thoại: ${item.biThu.dienThoai}\n\nTrưởng Khu phố:\n${item.truongKhuPho.hoTen}\n${item.truongKhuPho.chucDanh}\nĐiện thoại: ${item.truongKhuPho.dienThoai}\n\nTrụ sở:\n${item.truSo}\n\nBản đồ:\n${mapSearchUrl(item)}`;
  }
  async function shareItem(id) {
    const item = data.khuPho.find((x) => x.id === id); if (!item) return;
    const text = shareText(item);
    try {
      if (navigator.share) await navigator.share({title:`Khu phố ${item.khuPho} - Phường Mỹ Ngãi`, text, url:mapSearchUrl(item)});
      else await copyText(text, '✓ Đã sao chép thông tin để chia sẻ');
    } catch (error) { if (error?.name !== 'AbortError') await copyText(text, '✓ Đã sao chép thông tin để chia sẻ'); }
  }

  function renderKhuPhoCard(item) {
    const gpsReady = validGps(item.gps); const dist = distanceText(item);
    return `
      <article class="directory-card" data-id="${item.id}">
        <div class="card-top"><div class="card-no">${String(item.id).padStart(2,'0')}</div><small>Khu phố</small><h3>${escapeHtml(item.khuPho)}</h3></div>
        <section class="person" aria-label="Bí thư Chi bộ ${escapeHtml(item.khuPho)}"><span class="role-badge">◆ Bí thư Chi bộ</span><h4>${escapeHtml(item.biThu.hoTen)}</h4><p class="title">${escapeHtml(item.biThu.chucDanh)}</p>${phoneActions(item.biThu,item.biThu.hoTen)}</section>
        <section class="person" aria-label="Trưởng Khu phố ${escapeHtml(item.khuPho)}"><span class="role-badge leader">● Trưởng Khu phố</span><h4>${escapeHtml(item.truongKhuPho.hoTen)}</h4><p class="title">${escapeHtml(item.truongKhuPho.chucDanh)}</p>${phoneActions(item.truongKhuPho,item.truongKhuPho.hoTen)}</section>
        <div class="location"><span class="location-icon" aria-hidden="true">⌖</span><div class="location-content"><b>TRỤ SỞ</b><p>${escapeHtml(item.truSo)}</p>
          <div class="location-meta"><span class="location-badge ${gpsReady?'ready':''}">${gpsReady?'● GPS chính xác':'○ Bản đồ theo địa chỉ'}</span>${dist?`<span class="location-badge ${gpsReady?'ready':''}">${escapeHtml(dist)}</span>`:''}</div>
          <div class="location-actions"><button class="map-btn" type="button" data-map-area="${item.id}">▣ Xem bản đồ & QR</button><a class="map-btn quick-route" href="${escapeHtml(directionsUrl(item))}" target="_blank" rel="noopener noreferrer">↗ Chỉ đường</a></div>
        </div></div>
        <button class="share-btn" type="button" data-share="${item.id}">↗ Chia sẻ thông tin</button>
      </article>`;
  }

  function filteredKhuPho() {
    const q = normalizeVietnamese(state.query), phoneQ = normalizePhone(state.query);
    return data.khuPho.filter((item) => {
      if (state.area !== 'all' && item.khuPho !== state.area) return false;
      if (state.role !== 'all' && state.query) {
        const person = state.role === 'secretary' ? item.biThu : item.truongKhuPho;
        const t = normalizeVietnamese(`${person.hoTen} ${person.chucDanh} ${person.dienThoai}`);
        if (!(t.includes(q) || normalizePhone(person.dienThoai).includes(phoneQ))) return false;
      }
      if (!state.query) return true;
      const searchable = normalizeVietnamese(`${item.khuPho} ${item.biThu.hoTen} ${item.biThu.chucDanh} ${item.biThu.dienThoai} ${item.truongKhuPho.hoTen} ${item.truongKhuPho.chucDanh} ${item.truongKhuPho.dienThoai} ${item.truSo} ${item.viTriBanDo || ''}`);
      const phones = `${normalizePhone(item.biThu.dienThoai)} ${normalizePhone(item.truongKhuPho.dienThoai)}`;
      return searchable.includes(q) || (phoneQ && phones.includes(phoneQ));
    });
  }

  function filteredStaff() {
    const q = normalizeVietnamese(state.query), phoneQ = normalizePhone(state.query);
    return data.staff.filter((item) => {
      if (state.section !== 'all' && item.sectionCode !== state.section) return false;
      if (state.group !== 'all' && item.group !== state.group) return false;
      if (!state.query) return true;
      const searchable = normalizeVietnamese(`${item.hoTen} ${item.chucDanh} ${item.section} ${item.group} ${item.dienThoai} ${item.email}`);
      return searchable.includes(q) || (phoneQ && normalizePhone(item.dienThoai).includes(phoneQ));
    });
  }

  function staffCard(item) {
    return `<article class="staff-card"><h4 class="staff-name">${escapeHtml(item.hoTen)}</h4><p class="staff-role">${escapeHtml(item.chucDanh)}</p>${phoneActions(item,item.hoTen)}</article>`;
  }
  function renderStaff(dataSet) {
    const sectionOrder = [...new Set(data.staff.map(x => x.sectionCode))];
    const sections = sectionOrder.map(code => ({code, items:dataSet.filter(x => x.sectionCode === code)})).filter(s => s.items.length);
    staffDirectory.innerHTML = sections.map((section) => {
      const label = section.items[0]?.section || section.code;
      const groupOrder = [...new Set(section.items.map(x => x.group || ''))];
      const groups = groupOrder.map(group => ({group, items:section.items.filter(x => (x.group || '') === group)}));
      return `<section class="staff-section"><div class="staff-section-head"><h3>${escapeHtml(label)}</h3><span>${section.items.length} người</span></div>${groups.map(g => `<div class="staff-group">${g.group?`<h4 class="staff-group-title">${escapeHtml(g.group)}</h4>`:''}<div class="staff-grid">${g.items.map(staffCard).join('')}</div></div>`).join('')}</section>`;
    }).join('');
  }

  function render() {
    if (state.mode === 'khuPho') {
      const result = filteredKhuPho();
      grid.innerHTML = result.map(renderKhuPhoCard).join(''); grid.hidden = result.length === 0; staffDirectory.hidden = true;
      emptyState.hidden = result.length !== 0; resultCount.textContent = `${result.length} khu phố`; $('#directoryTitle').textContent = '12 khu phố Phường Mỹ Ngãi';
      $('#directoryTag').textContent = 'Danh bạ Khu phố'; $('#directoryDescription').textContent = 'Dữ liệu Chi bộ và Khu phố sử dụng bản cập nhật riêng của ứng dụng.';
    } else {
      const result = filteredStaff(); renderStaff(result); staffDirectory.hidden = result.length === 0; grid.hidden = true;
      emptyState.hidden = result.length !== 0; resultCount.textContent = `${result.length} người`; $('#directoryTitle').textContent = 'Danh bạ cán bộ, công chức Phường Mỹ Ngãi';
      $('#directoryTag').textContent = 'Danh bạ cơ quan'; $('#directoryDescription').textContent = 'Đã nhập các mục A-G của danh bạ được cung cấp; không dùng các mục Chi bộ/Khu phố cũ để ghi đè dữ liệu hiện hành.';
    }
    clearSearchBtn.hidden = !state.query;
  }

  function resetFilters(keepMode = true) {
    state.query=''; state.area='all'; state.role='all'; state.section='all'; state.group='all';
    searchInput.value=''; areaFilter.value='all'; roleFilter.value='all'; sectionFilter.value='all'; groupFilter.value='all';
    updateGroupOptions(); render(); if (!keepMode) switchMode('khuPho');
  }

  function switchMode(mode) {
    state.mode = mode; state.query=''; searchInput.value='';
    document.querySelectorAll('.mode-tab').forEach(btn => { const active=btn.dataset.mode===mode; btn.classList.toggle('active',active); btn.setAttribute('aria-selected',String(active)); });
    $('#areaFilters').hidden = mode !== 'khuPho'; $('#staffFilters').hidden = mode !== 'canBo'; $('#locationTools').hidden = mode !== 'khuPho';
    searchInput.placeholder = mode === 'khuPho' ? 'Tìm khu phố, họ tên, chức danh hoặc số điện thoại...' : 'Tìm họ tên, chức danh, cơ quan hoặc số điện thoại...';
    render();
  }

  function populateFilters() {
    areaFilter.innerHTML = '<option value="all">Tất cả khu phố</option>' + data.khuPho.map(x => `<option value="${escapeHtml(x.khuPho)}">${escapeHtml(x.khuPho)}</option>`).join('');
    const sections = [...new Map(data.staff.map(x => [x.sectionCode,x.section])).entries()];
    sectionFilter.innerHTML = '<option value="all">Tất cả cơ quan, đơn vị</option>' + sections.map(([code,label]) => `<option value="${escapeHtml(code)}">${escapeHtml(label)}</option>`).join('');
    updateGroupOptions();
  }
  function updateGroupOptions() {
    const source = state.section === 'all' ? data.staff : data.staff.filter(x => x.sectionCode === state.section);
    const groups = [...new Set(source.map(x => x.group).filter(Boolean))];
    groupFilter.innerHTML = '<option value="all">Tất cả nhóm</option>' + groups.map(g => `<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`).join('');
    if (!groups.includes(state.group)) { state.group='all'; groupFilter.value='all'; }
  }

  function setupEvents() {
    document.querySelectorAll('.mode-tab').forEach(btn => btn.addEventListener('click', () => switchMode(btn.dataset.mode)));
    searchInput.addEventListener('input', e => {state.query=e.target.value;render();});
    clearSearchBtn.addEventListener('click',()=>{state.query='';searchInput.value='';render();searchInput.focus();});
    areaFilter.addEventListener('change',e=>{state.area=e.target.value;render();}); roleFilter.addEventListener('change',e=>{state.role=e.target.value;render();});
    sectionFilter.addEventListener('change',e=>{state.section=e.target.value;state.group='all';updateGroupOptions();render();}); groupFilter.addEventListener('change',e=>{state.group=e.target.value;render();});
    $('#resetFilters').addEventListener('click',()=>resetFilters()); $('#resetStaffFilters').addEventListener('click',()=>resetFilters()); $('#emptyReset').addEventListener('click',()=>resetFilters());
    document.body.addEventListener('click', e => {
      const copy=e.target.closest('[data-copy]'), share=e.target.closest('[data-share]'), map=e.target.closest('[data-map-area]');
      if(copy) copyText(copy.dataset.copy,'✓ Đã sao chép số điện thoại');
      if(share) shareItem(Number(share.dataset.share));
      if(map){const item=data.khuPho.find(x=>x.id===Number(map.dataset.mapArea));if(item) openMap(item,`Trụ sở Khu phố ${item.khuPho}`);}
    });
    $('#officeMapBtn').addEventListener('click',()=>openMap(data.meta,'UBND Phường Mỹ Ngãi'));
    $('#closeMapDialog').addEventListener('click',()=>mapDialog.close()); mapDialog.addEventListener('click',e=>{if(e.target===mapDialog) mapDialog.close();});
    $('#copyMapLink').addEventListener('click',()=>copyText(state.currentMapLink,'✓ Đã sao chép đường dẫn bản đồ'));
    $('#useMyLocation').addEventListener('click',requestLocation); $('#clearMyLocation').addEventListener('click',()=>{state.userLocation=null;$('#clearMyLocation').hidden=true;$('#geoHint').textContent='Vị trí đã được xóa khỏi phiên làm việc. Ứng dụng chỉ hỏi quyền vị trí khi bạn bấm nút.';render();});
  }

  function openMap(item,title) {
    const searchLink=mapSearchUrl(item); state.currentMapLink=searchLink;
    $('#mapDialogTitle').textContent=title; $('#mapAddress').textContent=item.truSo || item.diaChi || item.mapQuery || '';
    $('#mapFrame').src=mapEmbedUrl(item); $('#mapDirections').href=directionsUrl(item); $('#mapQr').src=qrUrl(searchLink);
    $('#mapGpsStatus').textContent=validGps(item.gps)?`GPS chính xác: ${Number(item.gps.lat).toFixed(7)}, ${Number(item.gps.lng).toFixed(7)}`:'Chưa có tọa độ GPS xác nhận; bản đồ đang ghim theo địa chỉ.';
    $('#mapDistance').textContent=state.userLocation?(distanceText(item)||'Khoảng cách chưa khả dụng'):'Bấm “Dùng vị trí của tôi” để tính khoảng cách khi điểm đến có GPS chính xác.';
    if(typeof mapDialog.showModal==='function') mapDialog.showModal(); else mapDialog.setAttribute('open','');
  }

  function requestLocation() {
    if(!navigator.geolocation){showToast('Trình duyệt không hỗ trợ định vị.');return;}
    const btn=$('#useMyLocation'); const original=btn.textContent; btn.disabled=true;btn.textContent='Đang xác định vị trí…';
    navigator.geolocation.getCurrentPosition(pos=>{
      state.userLocation={lat:pos.coords.latitude,lng:pos.coords.longitude,accuracy:pos.coords.accuracy};
      $('#geoHint').textContent=`Đã nhận vị trí hiện tại (độ chính xác khoảng ${Math.round(pos.coords.accuracy)} m). Vị trí chỉ dùng trong phiên này để tính khoảng cách/chỉ đường.`;
      $('#clearMyLocation').hidden=false; btn.disabled=false;btn.textContent=original;render();showToast('✓ Đã cập nhật vị trí hiện tại');
    },err=>{btn.disabled=false;btn.textContent=original;showToast(err.code===1?'Bạn chưa cho phép truy cập vị trí.':'Không lấy được vị trí hiện tại.');},{enableHighAccuracy:true,timeout:12000,maximumAge:30000});
  }

  function setupTheme() {
    const root=document.documentElement,saved=localStorage.getItem('myngai-theme'),preferred=window.matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light';let current=saved||preferred;
    const apply=()=>{root.dataset.theme=current;$('#themeIcon').textContent=current==='dark'?'☀':'☾';};apply();
    $('#themeToggle').addEventListener('click',()=>{current=current==='dark'?'light':'dark';localStorage.setItem('myngai-theme',current);apply();});
  }
  function setupCounters() {
    $('#statAreas').dataset.target=data.khuPho.length; $('#statAreaContacts').dataset.target=data.khuPho.length*2; $('#statStaff').dataset.target=data.staff.length; $('#statStaffPhones').dataset.target=data.staff.filter(x=>normalizePhone(x.dienThoai)).length;
    const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    document.querySelectorAll('.counter').forEach(c=>{const target=Number(c.dataset.target||0);if(reduce){c.textContent=target;return;}const start=performance.now(),duration=650;const step=now=>{const p=Math.min(1,(now-start)/duration);c.textContent=Math.round(target*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(step);};requestAnimationFrame(step);});
  }
  function setupBackToTop(){const b=$('#backToTop'),update=()=>b.classList.toggle('show',window.scrollY>500);window.addEventListener('scroll',update,{passive:true});update();b.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));}
  function setupPWA(){if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/service-worker.js').catch(()=>{}));}

  function init(){
    setupTheme(); populateFilters(); setupEvents(); setupCounters(); setupBackToTop(); setupPWA();
    $('#year').textContent=new Date().getFullYear(); $('#officeAddress').textContent=data.meta.diaChi; render();
  }
  init();
})();
