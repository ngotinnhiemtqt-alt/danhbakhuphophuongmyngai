// Dữ liệu nguồn của ứng dụng.
// Không tự suy đoán tọa độ GPS. Tọa độ chính xác có thể được cập nhật tại /admin.html.

const appMeta = {
  "tenDonVi": "ỦY BAN NHÂN DÂN PHƯỜNG MỸ NGÃI",
  "diaChi": "Số 324, đường Mai Văn Khải, Khu phố Mỹ Tân, phường Mỹ Ngãi, tỉnh Đồng Tháp",
  "dienThoai": "02773.851.558",
  "email": "phuongmyngai@dongthap.gov.vn",
  "mapQuery": "Số 324, đường Mai Văn Khải, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
  "gps": null,
  "sourceNote": "Danh bạ cán bộ, công chức lấy từ PDF người dùng cung cấp; các mục Chi bộ/Khu phố trong PDF không được nhập đè vì ứng dụng đang dùng dữ liệu cập nhật riêng."
};

const khuPhoData = [
  {
    "id": 1,
    "khuPho": "Tân An",
    "biThu": {
      "hoTen": "Dương Thị Thu Ba",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0939 669 509"
    },
    "truongKhuPho": {
      "hoTen": "Nguyễn Thị Vân Nhung",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0903 304 060"
    },
    "truSo": "Quốc lộ 30, tổ 7, Khu phố Tân An (trụ sở Khóm 1 cũ)",
    "viTriBanDo": "Quốc lộ 30, Tổ 7, Khu phố Tân An, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 2,
    "khuPho": "Trần Quốc Toản",
    "biThu": {
      "hoTen": "Nguyễn Thị Kim Loan",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0919 121 274"
    },
    "truongKhuPho": {
      "hoTen": "Lê Hoàng Vinh",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0939 703 435"
    },
    "truSo": "Số 71, đường Tân Định, tổ 21, Khu phố Trần Quốc Toản (trụ sở Khóm 3 cũ)",
    "viTriBanDo": "Số 71, đường Tân Định, Tổ 21, Khu phố Trần Quốc Toản, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 3,
    "khuPho": "Tân Định",
    "biThu": {
      "hoTen": "Nguyễn Thành Được",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0969 890 113"
    },
    "truongKhuPho": {
      "hoTen": "Nguyễn Văn Sang",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0988 165 716"
    },
    "truSo": "Đường Lưu Kim Phong, Tổ 32, Khu phố Tân Định (trụ sở Khóm 4 cũ)",
    "viTriBanDo": "Đường Lưu Kim Phong, Tổ 32, Khu phố Tân Định, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 4,
    "khuPho": "Mỹ Phước",
    "biThu": {
      "hoTen": "Nguyễn Thị Kim Thúy",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0939 606 164"
    },
    "truongKhuPho": {
      "hoTen": "Võ Thanh Hòa",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0939 537 767"
    },
    "truSo": "Đường Nguyễn Chí Thanh, Khu phố Mỹ Phước (trụ sở Khóm 7 cũ)",
    "viTriBanDo": "Đường Nguyễn Chí Thanh, Khu phố Mỹ Phước, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 5,
    "khuPho": "Tân Nhất",
    "biThu": {
      "hoTen": "Nguyễn Văn Thanh",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0939 200 919"
    },
    "truongKhuPho": {
      "hoTen": "Lê Thị Bạch Ngọc",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0396 949 060"
    },
    "truSo": "Tổ 15, đường ấp Chiến Lược, Khu phố Tân Nhất (trụ sở Khóm 9 cũ)",
    "viTriBanDo": "Tổ 15, đường Ấp Chiến Lược, Khu phố Tân Nhất, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 6,
    "khuPho": "Mỹ Tân",
    "biThu": {
      "hoTen": "Nguyễn Thái Hồ",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0907 760 916"
    },
    "truongKhuPho": {
      "hoTen": "Nguyễn Văn Trường",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0988 522 833"
    },
    "truSo": "Khu dân cư Bà Học, đường số 4, tổ 12, Khu phố Mỹ Tân (trụ sở Khóm 10 cũ)",
    "viTriBanDo": "Khu dân cư Bà Học, đường số 4, Tổ 12, Khu phố Mỹ Tân, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 7,
    "khuPho": "Mỹ Phong",
    "biThu": {
      "hoTen": "Huỳnh Văn Diệu",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0913 831 064"
    },
    "truongKhuPho": {
      "hoTen": "Hồ Bảo Triệu Duy",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0907 466 586"
    },
    "truSo": "Số 39 đường số 2, tổ 3, Khu phố Mỹ Phong (trụ sở Khóm 11 cũ)",
    "viTriBanDo": "Số 39 đường số 2, Tổ 3, Khu phố Mỹ Phong, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 8,
    "khuPho": "Mỹ Lợi",
    "biThu": {
      "hoTen": "Thái Nguyên",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0362 998 113"
    },
    "truongKhuPho": {
      "hoTen": "Lê Văn Phú Quý",
      "chucDanh": "Trưởng Khu phố",
      "dienThoai": "0768 506 711"
    },
    "truSo": "Đường Bà Học bờ trên, Tổ 7, Khu phố Mỹ Lợi (trụ sở Khóm 12 cũ)",
    "viTriBanDo": "Đường Bà Học bờ trên, Tổ 7, Khu phố Mỹ Lợi, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 9,
    "khuPho": "Tân Tiến",
    "biThu": {
      "hoTen": "Nguyễn Văn Liếng",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0762 925 762"
    },
    "truongKhuPho": {
      "hoTen": "Nguyễn Văn Mơ",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0899 308 970"
    },
    "truSo": "Tổ 12, đường Ngã Đồng, Khu phố Tân Tiến (trụ sở Khóm 13 cũ, gần bến đò 5 Vui)",
    "viTriBanDo": "Tổ 12, đường Ngã Đồng, Khu phố Tân Tiến, gần bến đò 5 Vui, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 10,
    "khuPho": "Tân Nghĩa",
    "biThu": {
      "hoTen": "Phan Văn Nghĩa",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0944 346 484"
    },
    "truongKhuPho": {
      "hoTen": "Huỳnh Văn Thắng",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0337 272 846"
    },
    "truSo": "Tổ 1, Khu phố Tân Nghĩa (Trung tâm Văn hóa học tập cộng đồng xã Tân Nghĩa cũ)",
    "viTriBanDo": "Trung tâm Văn hóa học tập cộng đồng xã Tân Nghĩa cũ, Tổ 1, Khu phố Tân Nghĩa, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 11,
    "khuPho": "Tân Hòa",
    "biThu": {
      "hoTen": "Trương Thanh Vĩnh",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0327 610 657"
    },
    "truongKhuPho": {
      "hoTen": "Mai Văn Tấn Đạt",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0385 789 354"
    },
    "truSo": "Bờ Nam kênh Ông Kho, Tổ 03, Khu phố Tân Hòa (trụ sở Khóm 15 cũ)",
    "viTriBanDo": "Bờ Nam kênh Ông Kho, Tổ 03, Khu phố Tân Hòa, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  },
  {
    "id": 12,
    "khuPho": "Tân Thuận",
    "biThu": {
      "hoTen": "Lê Văn Lên",
      "chucDanh": "Bí thư Chi bộ",
      "dienThoai": "0948 293 348"
    },
    "truongKhuPho": {
      "hoTen": "Lê Thị Như Ngọc",
      "chucDanh": "Phó Bí thư Chi bộ, Trưởng Khu phố",
      "dienThoai": "0382 859 881"
    },
    "truSo": "Đường Bà Đông kênh Tư Tịnh, Tổ 13, Khu phố Tân Thuận (trụ sở Khóm 16 cũ)",
    "viTriBanDo": "Đường Bà Đông kênh Tư Tịnh, Tổ 13, Khu phố Tân Thuận, Phường Mỹ Ngãi, Đồng Tháp, Việt Nam",
    "gps": null
  }
];

const danhBaCanBoData = [
  {
    "id": "CB001",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "I. Thường trực Đảng uỷ",
    "stt": "01",
    "hoTen": "Võ Phan Thành Minh",
    "chucDanh": "Bí thư Đảng uỷ, Chủ tịch HĐND",
    "dienThoai": "0903.040.449",
    "email": ""
  },
  {
    "id": "CB002",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "I. Thường trực Đảng uỷ",
    "stt": "02",
    "hoTen": "Nguyễn Ngọc Luân Lý",
    "chucDanh": "Phó Bí thư Thường trực",
    "dienThoai": "0908.061.681",
    "email": ""
  },
  {
    "id": "CB003",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "I. Thường trực Đảng uỷ",
    "stt": "03",
    "hoTen": "Nguyễn Hoàng Hơn",
    "chucDanh": "Phó Bí thư, Chủ tịch UBND",
    "dienThoai": "0906.277.689",
    "email": ""
  },
  {
    "id": "CB004",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "01",
    "hoTen": "Lê Văn Tuấn",
    "chucDanh": "UVTV, Chánh văn phòng ĐU",
    "dienThoai": "0918.754.864",
    "email": ""
  },
  {
    "id": "CB005",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "02",
    "hoTen": "Võ Nguyễn Trường Phúc",
    "chucDanh": "Phó Chánh văn phòng Đảng uỷ",
    "dienThoai": "0913.612.350",
    "email": ""
  },
  {
    "id": "CB006",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "03",
    "hoTen": "Phan Thị Thu Hai",
    "chucDanh": "Phó Chánh Văn phòng Đảng uỷ",
    "dienThoai": "0907.628.383",
    "email": ""
  },
  {
    "id": "CB007",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "04",
    "hoTen": "Hồ Thanh Nhàn",
    "chucDanh": "Chuyên viên Văn phòng Đảng uỷ",
    "dienThoai": "0973.373.162",
    "email": ""
  },
  {
    "id": "CB008",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "05",
    "hoTen": "Lê Thị Diễm Kiều",
    "chucDanh": "Chuyên viên Văn phòng Đảng uỷ",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB009",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "06",
    "hoTen": "Lê Thị Phương Thảo",
    "chucDanh": "Chuyên viên Văn phòng Đảng uỷ",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB010",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "07",
    "hoTen": "Huỳnh Duy Khanh",
    "chucDanh": "Chuyên viên Văn phòng Đảng uỷ",
    "dienThoai": "0945.949.379",
    "email": ""
  },
  {
    "id": "CB011",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "II. Văn phòng Đảng uỷ",
    "stt": "08",
    "hoTen": "Cao Văn Lời",
    "chucDanh": "Chuyên viên Văn phòng Đảng uỷ",
    "dienThoai": "0906.106.930",
    "email": ""
  },
  {
    "id": "CB012",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "III. Ban Xây dựng đảng Đảng uỷ",
    "stt": "01",
    "hoTen": "Mai Kiến Trúc",
    "chucDanh": "UVTV Đảng uỷ, Trưởng ban XDĐ",
    "dienThoai": "0919.501.677",
    "email": ""
  },
  {
    "id": "CB013",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "III. Ban Xây dựng đảng Đảng uỷ",
    "stt": "02",
    "hoTen": "Lê Thị Bích Thuỷ",
    "chucDanh": "Phó Trưởng ban XDĐ",
    "dienThoai": "0916.777.960",
    "email": ""
  },
  {
    "id": "CB014",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "III. Ban Xây dựng đảng Đảng uỷ",
    "stt": "03",
    "hoTen": "Lê Thị Liên",
    "chucDanh": "Chuyên viên Ban XDĐ",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB015",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "III. Ban Xây dựng đảng Đảng uỷ",
    "stt": "04",
    "hoTen": "Nguyễn Ngô Diễm Hương",
    "chucDanh": "Chuyên viên Ban XDĐ",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB016",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "III. Ban Xây dựng đảng Đảng uỷ",
    "stt": "05",
    "hoTen": "Lê Thị Minh Thanh",
    "chucDanh": "Chuyên viên Ban XDĐ",
    "dienThoai": "0904.511.473",
    "email": ""
  },
  {
    "id": "CB017",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "IV. Cơ quan Uỷ ban kiểm tra Đảng uỷ",
    "stt": "01",
    "hoTen": "Nguyễn Tiến Sĩ",
    "chucDanh": "UVTV Đảng uỷ, Chủ nhiệm UBKT",
    "dienThoai": "0903.101.832",
    "email": ""
  },
  {
    "id": "CB018",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "IV. Cơ quan Uỷ ban kiểm tra Đảng uỷ",
    "stt": "02",
    "hoTen": "Nguyễn Thị Trà My",
    "chucDanh": "ĐUV, Phó Chủ nhiệm UBKT ĐU",
    "dienThoai": "0979.828.678",
    "email": ""
  },
  {
    "id": "CB019",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "IV. Cơ quan Uỷ ban kiểm tra Đảng uỷ",
    "stt": "03",
    "hoTen": "Huỳnh Lê Minh",
    "chucDanh": "Phó Chủ nhiệm UBKT ĐU",
    "dienThoai": "0918.750.786",
    "email": ""
  },
  {
    "id": "CB020",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "IV. Cơ quan Uỷ ban kiểm tra Đảng uỷ",
    "stt": "04",
    "hoTen": "Trần Thị Mười",
    "chucDanh": "Uỷ viên UBKT ĐU",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB021",
    "sectionCode": "A",
    "section": "A – ĐẢNG UỶ",
    "group": "IV. Cơ quan Uỷ ban kiểm tra Đảng uỷ",
    "stt": "05",
    "hoTen": "Đặng Ngọc Linh",
    "chucDanh": "Uỷ viên UBKT ĐU",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB022",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "01",
    "hoTen": "Phạm Thị Xuân Mai",
    "chucDanh": "UVBTV, Chủ tịch MTTQ Phường",
    "dienThoai": "0913.947.827",
    "email": ""
  },
  {
    "id": "CB023",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "02",
    "hoTen": "Trần Văn Thảo",
    "chucDanh": "ĐUV, PCTTT MTTQ, đồng thời Chủ tịch Hội Nông dân",
    "dienThoai": "0913.170.347",
    "email": ""
  },
  {
    "id": "CB024",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "03",
    "hoTen": "Nguyễn Thị Hồng Thắm",
    "chucDanh": "ĐUV, Phó Chủ tịch MTTQ kiêm Chủ tịch Hội Liên hiệp Phụ nữ",
    "dienThoai": "0973.974.998",
    "email": ""
  },
  {
    "id": "CB025",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "04",
    "hoTen": "Đỗ Hữu Ân",
    "chucDanh": "Đảng uỷ viên, Phó Chủ tịch MTTQ kiêm Bí thư Đoàn Thanh niên",
    "dienThoai": "0949.577.657",
    "email": ""
  },
  {
    "id": "CB026",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "05",
    "hoTen": "Hồ Nguyễn Liên Phương",
    "chucDanh": "Đảng uỷ viên, Phó Chủ tịch MTTQ kiêm Chủ tịch Liên đoàn Lao động",
    "dienThoai": "0918.809.046",
    "email": ""
  },
  {
    "id": "CB027",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "06",
    "hoTen": "Lê Văn Diễn",
    "chucDanh": "Phó Chủ tịch MTTQ VN kiêm Chủ tịch Hội Cựu chiến binh",
    "dienThoai": "0399.120.520",
    "email": ""
  },
  {
    "id": "CB028",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "07",
    "hoTen": "Trần Hữu Tâm",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0815.899.617",
    "email": ""
  },
  {
    "id": "CB029",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "08",
    "hoTen": "Nguyễn Thị Hồng Nhung",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0919.870.926",
    "email": ""
  },
  {
    "id": "CB030",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "09",
    "hoTen": "Nguyễn Thành Nguyên",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0794.209.475",
    "email": ""
  },
  {
    "id": "CB031",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "10",
    "hoTen": "Nguyễn Văn Chí Hiền",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0916.220.676",
    "email": ""
  },
  {
    "id": "CB032",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "11",
    "hoTen": "Trần Thị Như Ngọc",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0854.635.533",
    "email": ""
  },
  {
    "id": "CB033",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "12",
    "hoTen": "Lê Văn Lốc",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0366.495.425",
    "email": ""
  },
  {
    "id": "CB034",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "13",
    "hoTen": "Nguyễn Phú Trung",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0337.974.210",
    "email": ""
  },
  {
    "id": "CB035",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "14",
    "hoTen": "Trần Văn Oai",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0939.367.946",
    "email": ""
  },
  {
    "id": "CB036",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "15",
    "hoTen": "Huỳnh Tuyết Nhung",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0939.704.550",
    "email": ""
  },
  {
    "id": "CB037",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "16",
    "hoTen": "Nguyễn Vũ Linh",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0399.017.605",
    "email": ""
  },
  {
    "id": "CB038",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "17",
    "hoTen": "Lê Ngọc Thơ",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0776.878.446",
    "email": ""
  },
  {
    "id": "CB039",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "18",
    "hoTen": "Nguyễn Văn Hoàng",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0911.175.502",
    "email": ""
  },
  {
    "id": "CB040",
    "sectionCode": "B",
    "section": "B – MẶT TRẬN TỔ QUỐC",
    "group": "",
    "stt": "19",
    "hoTen": "Nguyễn Văn Tập",
    "chucDanh": "Chuyên viên cơ quan Uỷ ban MTTQ VN",
    "dienThoai": "0988.215.428",
    "email": ""
  },
  {
    "id": "CB041",
    "sectionCode": "C",
    "section": "C – HỘI ĐỒNG NHÂN DÂN",
    "group": "I. Lãnh đạo Hội đồng nhân dân",
    "stt": "01",
    "hoTen": "Lê Thị Hồng Huệ",
    "chucDanh": "UVTV Đảng uỷ, Phó chủ tịch HĐND",
    "dienThoai": "0916.944.445",
    "email": ""
  },
  {
    "id": "CB042",
    "sectionCode": "C",
    "section": "C – HỘI ĐỒNG NHÂN DÂN",
    "group": "II. Ban Kinh tế - Ngân sách",
    "stt": "01",
    "hoTen": "Phan Thanh Điền",
    "chucDanh": "ĐUV, Phó Trưởng ban Kinh tế - Ngân sách HĐND",
    "dienThoai": "0987.281.893",
    "email": ""
  },
  {
    "id": "CB043",
    "sectionCode": "C",
    "section": "C – HỘI ĐỒNG NHÂN DÂN",
    "group": "II. Ban Kinh tế - Ngân sách",
    "stt": "02",
    "hoTen": "Phan Ngọc Đông",
    "chucDanh": "Chuyên viên Ban Kinh tế - Ngân sách HĐND",
    "dienThoai": "0918.366.360",
    "email": ""
  },
  {
    "id": "CB044",
    "sectionCode": "C",
    "section": "C – HỘI ĐỒNG NHÂN DÂN",
    "group": "III. Ban Văn hoá – Xã hội",
    "stt": "01",
    "hoTen": "Phạm Anh Phúc",
    "chucDanh": "ĐUV, Phó Trưởng ban Kinh tế - Ngân sách HĐND",
    "dienThoai": "0886.909.590",
    "email": ""
  },
  {
    "id": "CB045",
    "sectionCode": "C",
    "section": "C – HỘI ĐỒNG NHÂN DÂN",
    "group": "III. Ban Văn hoá – Xã hội",
    "stt": "02",
    "hoTen": "Lê Thị Ngọc Hân",
    "chucDanh": "Chuyên viên Ban Văn hoá – Xã hội HĐND",
    "dienThoai": "0973.163.231",
    "email": ""
  },
  {
    "id": "CB046",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "I. Lãnh đạo Uỷ ban nhân dân",
    "stt": "01",
    "hoTen": "Nguyễn Hoàng Thanh",
    "chucDanh": "Phó Chủ tịch Ủy ban nhân dân",
    "dienThoai": "0979.720.414",
    "email": ""
  },
  {
    "id": "CB047",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "I. Lãnh đạo Uỷ ban nhân dân",
    "stt": "02",
    "hoTen": "Nguyễn Thị Mộng Thu",
    "chucDanh": "Phó Chủ tịch Ủy ban nhân dân",
    "dienThoai": "0913.613.998",
    "email": ""
  },
  {
    "id": "CB048",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "01",
    "hoTen": "Nguyễn Văn Hiếu",
    "chucDanh": "Chánh văn phòng HĐND và UBND",
    "dienThoai": "0903.942.233",
    "email": ""
  },
  {
    "id": "CB049",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "02",
    "hoTen": "Lê Cẩm Bình",
    "chucDanh": "Phó Chánh Văn phòng HĐND và UBND",
    "dienThoai": "0901.092.966",
    "email": ""
  },
  {
    "id": "CB050",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "03",
    "hoTen": "Phạm Hoàng Yến",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0939.054.454",
    "email": ""
  },
  {
    "id": "CB051",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "04",
    "hoTen": "Phan Thị Thúy",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0908.477.374",
    "email": ""
  },
  {
    "id": "CB052",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "05",
    "hoTen": "Cao Hoàn Hải",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0947.080.932",
    "email": ""
  },
  {
    "id": "CB053",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "06",
    "hoTen": "Trần Thị Thùy Dương",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0837.990.929",
    "email": ""
  },
  {
    "id": "CB054",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "07",
    "hoTen": "Nguyễn Thị Mỹ Hạnh",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0936.467.858",
    "email": ""
  },
  {
    "id": "CB055",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "08",
    "hoTen": "Lê Thị Thanh Thủy",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0976.037.391",
    "email": ""
  },
  {
    "id": "CB056",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "09",
    "hoTen": "Nguyễn Thị Tuyết Lan",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0896.717.167",
    "email": ""
  },
  {
    "id": "CB057",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "10",
    "hoTen": "Phạm Thùy Quyên",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0377.269.603",
    "email": ""
  },
  {
    "id": "CB058",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "11",
    "hoTen": "Lê Kim Khoa",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0975.314.369",
    "email": ""
  },
  {
    "id": "CB059",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "12",
    "hoTen": "Nguyễn Nhựt Trường",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0944.977.818",
    "email": ""
  },
  {
    "id": "CB060",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "13",
    "hoTen": "Lê Văn Dư",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0912.688.912",
    "email": ""
  },
  {
    "id": "CB061",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "14",
    "hoTen": "Lê Phú Cường",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0775.876.858",
    "email": ""
  },
  {
    "id": "CB062",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "15",
    "hoTen": "Nguyễn Sỹ Đan",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0962.007.297",
    "email": ""
  },
  {
    "id": "CB063",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "16",
    "hoTen": "Trần Thị Thi",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0913.041.602",
    "email": ""
  },
  {
    "id": "CB064",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "17",
    "hoTen": "Nguyễn Phước Thanh Trân",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0915.488.881",
    "email": ""
  },
  {
    "id": "CB065",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "18",
    "hoTen": "Nguyễn Thị Kim Oanh",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0989.862.475",
    "email": ""
  },
  {
    "id": "CB066",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "II. Văn phòng Hội đồng nhân dân và Uỷ ban nhân dân",
    "stt": "19",
    "hoTen": "Nguyễn Thị Ngọc Yến",
    "chucDanh": "Chuyên viên Văn phòng HĐND và UBND",
    "dienThoai": "0944.495.317",
    "email": ""
  },
  {
    "id": "CB067",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "01",
    "hoTen": "Đoàn Thị Cẩm Nhung",
    "chucDanh": "ĐUV, Trưởng Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0914.679.339",
    "email": ""
  },
  {
    "id": "CB068",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "02",
    "hoTen": "Lương Ngọc Dũng",
    "chucDanh": "Phó Trưởng Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0908.527.177",
    "email": ""
  },
  {
    "id": "CB069",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "03",
    "hoTen": "Nguyễn Thanh Tuấn",
    "chucDanh": "Phó Trưởng Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0916.904.332",
    "email": ""
  },
  {
    "id": "CB070",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "04",
    "hoTen": "Dương Hoàng Nam",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0819.168.849",
    "email": ""
  },
  {
    "id": "CB071",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "05",
    "hoTen": "Võ Thị Lệ Thu",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0377.286.550",
    "email": ""
  },
  {
    "id": "CB072",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "06",
    "hoTen": "Huỳnh Thị Kim Hằng",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0974.085.183",
    "email": ""
  },
  {
    "id": "CB073",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "07",
    "hoTen": "Nguyễn Thị Thuỷ",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0975.917.879",
    "email": ""
  },
  {
    "id": "CB074",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "08",
    "hoTen": "Nguyễn Hoàng Minh",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0399.997.009",
    "email": ""
  },
  {
    "id": "CB075",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "09",
    "hoTen": "Nguyễn Hữu Hòa",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0913.720.955",
    "email": ""
  },
  {
    "id": "CB076",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "10",
    "hoTen": "Phạm Văn Hồng Khanh",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0914.925.658",
    "email": ""
  },
  {
    "id": "CB077",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "11",
    "hoTen": "Trần Nguyễn Hữu Tài",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0913.847.014",
    "email": ""
  },
  {
    "id": "CB078",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "12",
    "hoTen": "Phạm Văn Đạt",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0838.723.823",
    "email": ""
  },
  {
    "id": "CB079",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "13",
    "hoTen": "Nguyễn Phạm Đức Thanh",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0845.067.009",
    "email": ""
  },
  {
    "id": "CB080",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "14",
    "hoTen": "Phạm Thị Hồng Liên",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0975.154.340",
    "email": ""
  },
  {
    "id": "CB081",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "III. Phòng Kinh tế, Hạ tầng và Đô thị",
    "stt": "15",
    "hoTen": "Nguyễn Ngọc Thạo",
    "chucDanh": "Chuyên viên Phòng Kinh tế, Hạ tầng và Đô thị",
    "dienThoai": "0917.401.959",
    "email": ""
  },
  {
    "id": "CB082",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "01",
    "hoTen": "Trương Thanh Phong",
    "chucDanh": "ĐUV, Trưởng Phòng Văn hoá - Xã hội",
    "dienThoai": "0919.119.376",
    "email": ""
  },
  {
    "id": "CB083",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "02",
    "hoTen": "Phạm Minh Thuỳ",
    "chucDanh": "Phó Trưởng Phòng Văn hoá - Xã hội",
    "dienThoai": "0399.097.373",
    "email": ""
  },
  {
    "id": "CB084",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "03",
    "hoTen": "Nguyễn Hồ Hải Yến",
    "chucDanh": "Phó Trưởng Phòng Văn hoá - Xã hội",
    "dienThoai": "0909.059.334",
    "email": ""
  },
  {
    "id": "CB085",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "04",
    "hoTen": "Trần Thị Tiểu Băng",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0765.151.363",
    "email": ""
  },
  {
    "id": "CB086",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "05",
    "hoTen": "Võ Thị Cẩm Tú",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0939.709.394",
    "email": ""
  },
  {
    "id": "CB087",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "06",
    "hoTen": "Hồ Thị Hồng Gấm",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0939.309.487",
    "email": ""
  },
  {
    "id": "CB088",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "07",
    "hoTen": "Lê Thị Xuân Mai",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0392.933.787",
    "email": ""
  },
  {
    "id": "CB089",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "08",
    "hoTen": "Võ Thị Kiều Oanh",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0901.090.915",
    "email": ""
  },
  {
    "id": "CB090",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "09",
    "hoTen": "Lê Thị Huệ",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0969.883.881",
    "email": ""
  },
  {
    "id": "CB091",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "IV. Phòng Văn hoá – Xã hội",
    "stt": "10",
    "hoTen": "Trần Ngọc Vẹn",
    "chucDanh": "Chuyên viên Phòng Văn hoá - Xã hội",
    "dienThoai": "0909.188.987",
    "email": ""
  },
  {
    "id": "CB092",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "01",
    "hoTen": "Lê Trần Phượng Khánh",
    "chucDanh": "Phó Giám đốc Trung tâm phục vụ Hành chính công",
    "dienThoai": "0774.710.122",
    "email": ""
  },
  {
    "id": "CB093",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "02",
    "hoTen": "Huỳnh Thị Tuyết Nga",
    "chucDanh": "Phó Giám đốc Trung tâm phục vụ Hành chính công",
    "dienThoai": "0965.436.262",
    "email": ""
  },
  {
    "id": "CB094",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "03",
    "hoTen": "Nguyễn Thị Hồng Nhung",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0975.640.378",
    "email": ""
  },
  {
    "id": "CB095",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "04",
    "hoTen": "Nguyễn Thị Trinh",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0368.576.949",
    "email": ""
  },
  {
    "id": "CB096",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "05",
    "hoTen": "Trần Thị Trang",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0972.411.361",
    "email": ""
  },
  {
    "id": "CB097",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "06",
    "hoTen": "Huỳnh Hải Hồ",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0909.192.785",
    "email": ""
  },
  {
    "id": "CB098",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "07",
    "hoTen": "Phan Ngọc Điệp",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0943.224.204",
    "email": ""
  },
  {
    "id": "CB099",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "08",
    "hoTen": "Nguyễn Thị Kim Cúc",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0366.760.883",
    "email": ""
  },
  {
    "id": "CB100",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "09",
    "hoTen": "Lê Bình Minh",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0918.815.984",
    "email": ""
  },
  {
    "id": "CB101",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "10",
    "hoTen": "Nguyễn Trung Tín",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0772.184.838",
    "email": ""
  },
  {
    "id": "CB102",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "11",
    "hoTen": "Trần Văn Lực",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0916.586.399",
    "email": ""
  },
  {
    "id": "CB103",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "12",
    "hoTen": "Trần Thị Ngọc Huyền",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0914.508.358",
    "email": ""
  },
  {
    "id": "CB104",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "13",
    "hoTen": "Nguyễn Thị Dứt",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0783.676.969",
    "email": ""
  },
  {
    "id": "CB105",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "14",
    "hoTen": "Bùi Thị Bảo Ngọc",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0368.823.141",
    "email": ""
  },
  {
    "id": "CB106",
    "sectionCode": "D",
    "section": "D – UỶ BAN NHÂN DÂN",
    "group": "V. Trung tâm Phục vụ hành chính công",
    "stt": "15",
    "hoTen": "Nguyễn Văn Khởi",
    "chucDanh": "Chuyên viên Trung tâm phục vụ Hành chính công",
    "dienThoai": "0987.281.545",
    "email": ""
  },
  {
    "id": "CB107",
    "sectionCode": "E",
    "section": "E - BAN CHỈ HUY QUÂN SỰ",
    "group": "",
    "stt": "01",
    "hoTen": "Nguyễn Nhật Trường",
    "chucDanh": "Chỉ huy trưởng BCHQS Phường",
    "dienThoai": "0949.729.029",
    "email": ""
  },
  {
    "id": "CB108",
    "sectionCode": "F",
    "section": "F – CÔNG AN PHƯỜNG",
    "group": "",
    "stt": "01",
    "hoTen": "Trần Văn Nho",
    "chucDanh": "Trưởng Công an",
    "dienThoai": "0919.028.157",
    "email": ""
  },
  {
    "id": "CB109",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "01",
    "hoTen": "Nguyễn Văn Phong",
    "chucDanh": "Giám đốc",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB110",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "02",
    "hoTen": "Lương Đức Phước",
    "chucDanh": "Phó Giám đốc",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB111",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "03",
    "hoTen": "Trương Thanh Hiền",
    "chucDanh": "Phó Giám đốc",
    "dienThoai": "0939.034.737",
    "email": ""
  },
  {
    "id": "CB112",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "04",
    "hoTen": "Nguyễn Hoài Vũ Linh",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB113",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "05",
    "hoTen": "Lâm Minh Thuấn",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB114",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "06",
    "hoTen": "Trần Hoàng Phương Nga",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB115",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "07",
    "hoTen": "Nguyễn Lê Trung Nghĩa",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB116",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "08",
    "hoTen": "Nguyễn Ngọc Chi",
    "chucDanh": "Kế toán trưởng",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB117",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "09",
    "hoTen": "Nguyễn Thị Trúc Tiên",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB118",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "10",
    "hoTen": "Nguyễn Thanh Trúc",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB119",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "11",
    "hoTen": "Lê Tấn Lộc",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB120",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "12",
    "hoTen": "Lê Hoàng Thúy An",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB121",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "13",
    "hoTen": "Nguyễn Lê Phương My",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB122",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "14",
    "hoTen": "Trần Trung Tín",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB123",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "15",
    "hoTen": "Trần Thị Tuyết Sương",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB124",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "16",
    "hoTen": "Trần Hoàng Anh",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB125",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "17",
    "hoTen": "Trần Minh Trí",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB126",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "18",
    "hoTen": "Nguyễn Tấn Lộc",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB127",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "19",
    "hoTen": "Phạm Văn Xoạn",
    "chucDanh": "Viên chức",
    "dienThoai": "",
    "email": ""
  },
  {
    "id": "CB128",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "20",
    "hoTen": "Nguyễn Thanh Tùng",
    "chucDanh": "Viên chức Tổ Bồi thường, HTTĐC",
    "dienThoai": "0909.939.405",
    "email": ""
  },
  {
    "id": "CB129",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "21",
    "hoTen": "Lê Duy Thuận",
    "chucDanh": "Viên chức Tổ Bồi thường, HTTĐC",
    "dienThoai": "0969.000.248",
    "email": ""
  },
  {
    "id": "CB130",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "22",
    "hoTen": "Bùi Vũ Linh",
    "chucDanh": "Viên chức Tổ Bồi thường, HTTĐC",
    "dienThoai": "0914.161.090",
    "email": ""
  },
  {
    "id": "CB131",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "23",
    "hoTen": "Nguyễn Văn Sẽ",
    "chucDanh": "Viên chức Tổ Bồi thường, HTTĐC",
    "dienThoai": "0939.444.340",
    "email": ""
  },
  {
    "id": "CB132",
    "sectionCode": "G",
    "section": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI",
    "group": "",
    "stt": "24",
    "hoTen": "Hoàng Liệu",
    "chucDanh": "Viên chức Tổ đấu giá",
    "dienThoai": "0983.131.191",
    "email": ""
  }
];

const danhMucCanBo = [
  {
    "code": "A",
    "label": "A – ĐẢNG UỶ"
  },
  {
    "code": "B",
    "label": "B – MẶT TRẬN TỔ QUỐC"
  },
  {
    "code": "C",
    "label": "C – HỘI ĐỒNG NHÂN DÂN"
  },
  {
    "code": "D",
    "label": "D – UỶ BAN NHÂN DÂN"
  },
  {
    "code": "E",
    "label": "E - BAN CHỈ HUY QUÂN SỰ"
  },
  {
    "code": "F",
    "label": "F – CÔNG AN PHƯỜNG"
  },
  {
    "code": "G",
    "label": "G - TRUNG TÂM CUNG ỨNG DỊCH VỤ CÔNG PHƯỜNG MỸ NGÃI"
  }
];
